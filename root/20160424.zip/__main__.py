import os
def main():
	os.startfile("game.exe")
if __name__ is "__main__":
	main()
	
